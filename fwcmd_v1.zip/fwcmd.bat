@echo off
title fwcmd (Funny Weird Command Prompt)
cls

:: --- CONFIGURATION ---
set "DRIVE_LETTER=E:"
set "TARGET_FOLDER=C:\fwcmd_storagedata" 
:: ---------------------

echo ===================================================
echo   Initializing Funny Weird Command Prompt...
echo ===================================================
echo.

if not exist "%TARGET_FOLDER%" mkdir "%TARGET_FOLDER%"

if exist %DRIVE_LETTER% (
    echo [INFO] %DRIVE_LETTER% is already mapped. Re-linking to ensure correct directory...
    subst %DRIVE_LETTER% /d >nul 2>&1
)

subst %DRIVE_LETTER% "%TARGET_FOLDER%"
label %DRIVE_LETTER% fwcmd >nul 2>&1

echo [SUCCESS] Drive %DRIVE_LETTER% (The fwcmd data drive DO NOT DELETE/FORMAT!) created and pointing to fwcmd_storagedata
echo.
echo Hi, Welcome to fwcmd. Type 'help' to see what you can do!
echo ===================================================
echo.

cd /d %DRIVE_LETTER%

:CMD_LOOP
set "user_input="
set /p "user_input=fwcmd %cd%> "

for /f "tokens=1* delims= " %%a in ("%user_input%") do (
    set "cmd_name=%%a"
    set "cmd_args=%%b"
)

:: --- CUSTOM COMMAND CHECKER ---
if "%cmd_name%"=="exit" goto CLOSE_PROGRAM
if "%cmd_name%"=="help" goto SHOW_HELP
if "%cmd_name%"=="echo" goto DO_ECHO
if "%cmd_name%"=="drivetools" goto DO_DRIVETOOLS
if "%cmd_name%"=="matrix" goto DO_MATRIX
if "%cmd_name%"=="speak" goto DO_SPEAK
if "%cmd_name%"=="rickroll" goto DO_RICKROLL
if "%cmd_name%"=="500" goto DO_500
if "%cmd_name%"=="un500" goto DO_UN500
if "%cmd_name%"=="color" goto DO_COLOR
if "%cmd_name%"=="popup" goto DO_POPUP
if "%cmd_name%"=="explode" goto DO_EXPLODE
if "%cmd_name%"=="ascii" goto DO_ASCII
if "%cmd_name%"=="flip" goto DO_FLIP
if "%cmd_name%"=="loading" goto DO_LOADING
if "%cmd_name%"=="randomcommand" goto DO_RANDOM_COMPILATION

:: --- THE 15 NEW COMMANDS ---
if "%cmd_name%"=="fortune" goto DO_FORTUNE
if "%cmd_name%"=="sysinfo" goto DO_SYSINFO
if "%cmd_name%"=="battery" goto DO_BATTERY
if "%cmd_name%"=="password" goto DO_PASSWORD
if "%cmd_name%"=="dice" goto DO_DICE
if "%cmd_name%"=="scare" goto DO_SCARE
if "%cmd_name%"=="calc" goto DO_CALC
if "%cmd_name%"=="notepad" goto DO_NOTEPAD
if "%cmd_name%"=="timer" goto DO_TIMER
if "%cmd_name%"=="fakeerror" goto DO_FAKEERROR
if "%cmd_name%"=="joke" goto DO_JOKE
if "%cmd_name%"=="clear" goto DO_CLEAR
if "%cmd_name%"=="space" goto DO_SPACE
if "%cmd_name%"=="inspect" goto DO_INSPECT
if "%cmd_name%"=="quote" goto DO_QUOTE

:: Block everything else
if not "%user_input%"=="" (
    echo Error: '%user_input%' is not a recognized fwcmd command.
    echo.
)
goto CMD_LOOP


:: --- COMMAND BEHAVIORS ---

:SHOW_HELP
echo.
echo === CORE COMMANDS ===
echo   echo [text]     - Repeats back whatever you type
echo   drivetools      - Shows stats about your custom E: drive
echo   speak [text]    - Makes your computer literally talk out loud
echo   matrix          - Floods your screen with weird hacker text
echo   rickroll        - Launches the exact Rick Astley video link
echo   500             - Instantly creates 500 fake virus logs in E:\
echo   un500           - Completely cleans up and deletes the 500 logs
echo   color [name]    - Changes prompt color (green, red, blue, hack)
echo   popup [text]    - Spawns a physical Windows error message window
echo   explode         - Simulates a dramatic terminal meltdown
echo   ascii           - Prints a massive retro title banner
echo   flip            - Flips a digital coin
echo   loading         - Runs a fake, stressful system progress bar
echo   randomcommand   - Triggers 1 of 70+ completely unpredictable behaviors!
echo.
echo === NEW COMMANDS ===
echo   fortune         - Opens a lucky digital fortune cookie
echo   sysinfo         - Displays safe, real-time custom computer system data
echo   battery         - Checks your laptop's current physical battery percentage
echo   password        - Generates a completely secure, random 12-character password
echo   dice            - Rolls a standard 6-sided gaming die
echo   scare           - Simulates a scary, fast-paced hard drive scanning event
echo   calc [A] [B]    - Instantly adds two numbers together
echo   notepad         - Safely pops open a blank Windows Notepad sheet
echo   timer [sec]     - Starts a custom terminal countdown timer
echo   fakeerror       - Spawns a critical-looking blue window alert box
echo   joke            - Prints a terrible, corny programming joke
echo   clear           - Resets and wipes the current terminal screen clean
echo   space           - Calculates remaining physical storage room on C:\
echo   inspect [file]  - Displays the raw text content inside a specific file
echo   quote           - Prints an inspiring tech quote to keep you motivated
echo   exit            - Safely close the tool and remove the drive
echo.
goto CMD_LOOP

:DO_ECHO
if "%cmd_args%"=="" (
    echo Echo what? Give me something to say!
) else (
    echo %cmd_args%
)
echo.
goto CMD_LOOP

:DO_DRIVETOOLS
echo.
echo === FWCMD DRIVE UTILITY ===
echo Drive Status: ACTIVE
echo Virtual Letter: %DRIVE_LETTER%
echo Physical Path: %TARGET_FOLDER%
echo.
echo Files inside fwcmd:
dir /b "%TARGET_FOLDER%" 2>nul || echo   (Drive is currently empty)
echo ===========================
echo.
goto CMD_LOOP

:DO_SPEAK
if "%cmd_args%"=="" (
    echo What do you want me to say? Example: speak hello human
) else (
    powershell -Command "Add-Type –AssemblyName System.Speech; (New-Object System.Speech.Synthesis.SpeechSynthesizer).Speak('%cmd_args%');" >nul 2>&1
)
echo.
goto CMD_LOOP

:DO_MATRIX
echo.
echo Press CTRL+C to stop the simulation...
ping 1.1.1.1 -n 1 -w 1000 >nul
setlocal enabledelayedexpansion
for /L %%i in (1,1,100) do (
    echo !random!!random!!random!!random!!random!!random!!random!!random!
)
endlocal
echo.
goto CMD_LOOP

:DO_RICKROLL
echo.
echo Opening the ultimate classic legendary masterpiece link...
start "" "https://youtube.com"
echo.
goto CMD_LOOP

:DO_500
echo.
echo [WARNING] Generating 500 junk files in %DRIVE_LETTER%...
for /L %%i in (1,1,500) do (
    echo Virus detection log number %%i > "%TARGET_FOLDER%\fake_virus_%%i.txt"
)
echo [SUCCESS] 500 fake virus logs successfully injected into E:\ drive. Run 'drivetools' to see them!
echo.
goto CMD_LOOP

:DO_UN500
echo.
echo [CLEANUP] Scrubbing %DRIVE_LETTER% drive clean...
del /q "%TARGET_FOLDER%\fake_virus_*.txt" >nul 2>&1
echo [SUCCESS] All 500 logs vaporized! Drive is clean.
echo.
goto CMD_LOOP

:DO_COLOR
if "%cmd_args%"=="green" color 0A
if "%cmd_args%"=="red" color 0C
if "%cmd_args%"=="blue" color 09
if "%cmd_args%"=="hack" color 02
if "%cmd_args%"=="" echo Choose a color: color green, color red, color blue, or color hack
echo.
goto CMD_LOOP

:DO_POPUP
if "%cmd_args%"=="" set "cmd_args=Unexpected error code 0xFUNNY"
powershell -Command "[System.Windows.Forms.MessageBox]::Show('%cmd_args%', 'fwcmd system alert')" >nul 2>&1
echo.
goto CMD_LOOP

:DO_EXPLODE
echo.
echo [CRITICAL ERROR] CORE MELTDOWN INITIATED.
color 0C
powershell -Command "Add-Type –AssemblyName System.Speech; (New-Object System.Speech.Synthesis.SpeechSynthesizer).Speak('Warning. Terminal will explode in 3. 2. 1.');" >nul 2>&1
echo 💥 BOOM! 💥
ping 1.1.1.1 -n 1 -w 1500 >nul
color 07
cls
goto DO_ASCII

:DO_ASCII
echo.
echo  ___________                      
echo                   
echo                                           
echo                                   
echo                                     
echo                                
echo                                     
echo.
goto CMD_LOOP

:DO_FLIP
echo.
set /a coin=%random% %% 2
if %coin%==0 echo 🪙 Result: HEADS!
if %coin%==1 echo 🪙 Result: TAILS!
echo.
goto CMD_LOOP

:DO_LOADING
echo.
echo Downloading more processing power...
set "bar="
for /L %%i in (1,1,20) do (
    set "bar=!bar!■"
    cls
    echo Processing: [!bar!] %%i0%%
    ping 1.1.1.1 -n 1 -w 100 >nul
)
echo [COMPLETE] RAM successfully downloaded.
echo.
goto CMD_LOOP

:: === NEW COMMAND LOGIC BLOCKS ===

:DO_FORTUNE
echo.
set /a fort=%random% %% 4
if %fort%==0 echo 🥠 Fortune: You will soon find a bug in your code that takes 4 hours to fix.
if %fort%==1 echo 🥠 Fortune: A clean desktop brings a clean mind. Yours is currently cluttered.
if %fort%==2 echo 🥠 Fortune: Someone is thinking about sending you a funny meme right now.
if %fort%==3 echo 🥠 Fortune: An unexpected system reboot is in your future if you don't save your files.
echo.
goto CMD_LOOP

:DO_SYSINFO
echo.
echo === FWCMD LIVE DEVICE MANIFEST ===
echo Current User Account: %USERNAME%
echo System Network Name:  %COMPUTERNAME%
echo Current Local Time:   %TIME%
echo Current Local Date:   %DATE%
echo OS Architecture:     %PROCESSOR_ARCHITECTURE%
echo ===================================
echo.
goto CMD_LOOP

:DO_BATTERY
echo.
powershell -Command "Get-CimInstance -ClassName Win32_Battery | Select-Object -Property EstimatedChargeRemaining, BatteryStatus" 2>nul || echo [INFO] Desktop detected. Main line alternating current connected. No battery array active.
echo.
goto CMD_LOOP

:DO_PASSWORD
echo.
echo Generating secure cryptographic key string...
powershell -Command "-join ((48..57) + (65..90) + (97..122) | Get-Random -Count 12 | ForEach-Object {[char]$_})"
echo.
goto CMD_LOOP

:DO_DICE
echo.
set /a diceroll=%random% %% 6 + 1
echo 🎲 You rolled a standard cube die: %diceroll%
echo.
goto CMD_LOOP

:DO_SCARE
echo.
color 0C
echo [CRITICAL ALERT] ANALYZING FILE SYSTEM ROOT STRUCTURE...
setlocal enabledelayedexpansion
for /L %%i in (1,1,40) do (
    echo DELETING CACHE MODULE REFERENCE: !random!!random!000x8f
    ping 1.1.1.1 -n 1 -w 30 >nul
)
endlocal
color 07
echo.
echo [RECOVERY COMPLETE] Just kidding. Your drive is completely safe!
echo.
goto CMD_LOOP

:DO_CALC
if "%cmd_args%"=="" (
    echo Error: Provide two numbers to add! Example: calc 5 12
) else (
    set /a sum=0
    for /f "tokens=1,2 delims= " %%a in ("%cmd_args%") do (
        set /a sum=%%a + %%b
    )
    echo Result: !sum!
)
echo.
